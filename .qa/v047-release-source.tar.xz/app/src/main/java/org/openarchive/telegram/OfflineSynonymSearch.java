package org.openarchive.telegram;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Deterministic local synonym expansion for an existing SQLite FTS4 index.
 * No AI, network, copying user content or claim of semantic understanding.
 * Only source text from the database can produce a hit.
 */
final class OfflineSynonymSearch {
    static final int MAX_CHARS=140, MAX_TERMS=7, MAX_ALTERNATIVES=12;
    private static final Map<String,List<String>> GROUPS=new LinkedHashMap<>();
    private static final Set<String> QUESTIONS=new LinkedHashSet<>(Arrays.asList(
        "найди","найти","покажи","показать","где","когда","что","какие","какой","какая",
        "мне","мы","вы","они","было","были","есть","про","об","это","этот",
        "сообщения","сообщение","сообщений","упоминали","говорили","обсуждали","все","среди"));
    static {
        group("компьютер", "компьютер", "комп", "компа", "компе", "компу", "компом", "пк", "pc");
        group("ноутбук", "ноутбук", "ноут", "ноута", "ноуте", "ноутом", "laptop");
        group("телефон", "телефон", "смартфон", "мобильник", "мобила", "мобилу");
        group("фотография", "фотография", "фотографии", "фотка", "фотки", "фото", "снимок");
        group("видео", "видео", "видос", "видосы", "ролик", "видеоролик");
        group("музыка", "музыка", "песня", "песни", "трек", "треки");
        group("автомобиль", "автомобиль", "машина", "авто", "тачка", "тачку");
        group("велосипед", "велосипед", "велик", "велика");
        group("деньги", "деньги", "деньгах", "денег", "бабки", "бабок", "наличные");
        group("работа", "работа", "работе", "работу", "труд", "работать");
        group("игра", "игра", "игры", "игру", "игрушка", "гейм");
        group("путешествие", "путешествие", "поездка", "поездку", "отпуск", "отпуске");
    }
    private static void group(String name,String... words){
        List<String> list=Collections.unmodifiableList(Arrays.asList(words));
        for(String word:words)GROUPS.put(word,list);
    }
    static final class Plan {
        final String fts,original,description;
        final List<String> terms;
        final List<String> searchTerms;
        final boolean expanded;
        Plan(String fts,String original,String description,List<String> terms,List<String> variants,boolean expanded){
            this.fts=fts;this.original=original;this.description=description;
            this.terms=Collections.unmodifiableList(terms);
            this.searchTerms=Collections.unmodifiableList(variants);
            this.expanded=expanded;
        }
        /** Human-checkable explanation; not a generated answer. */
        String sourceMatch(String body){
            if(body==null||body.isEmpty())return "Совпадение в индексе";
            String normalized=normalize(body);
            for(String token:terms)if(containsWord(normalized,token))return "Точное слово: "+token;
            for(String variant:searchTerms)if(containsWord(normalized,variant))return "Вариант: "+variant;
            return "Совпадение по началу слова";
        }
    }
    static Plan make(String input,boolean synonyms){
        if(input==null||input.trim().isEmpty())throw new IllegalArgumentException("Введите запрос");
        if(input.codePointCount(0,input.length())>MAX_CHARS)
            throw new IllegalArgumentException("Запрос длиннее 140 символов");
        String[] raw=normalize(input).split("[^\\p{L}\\p{N}]+");
        ArrayList<String> tokens=new ArrayList<>();
        for(String t:raw)if(t.length()>=2&&!tokens.contains(t))tokens.add(t);
        if(tokens.size()>1){
            ArrayList<String> cleaned=new ArrayList<>();
            for(String t:tokens)if(!QUESTIONS.contains(t))cleaned.add(t);
            if(!cleaned.isEmpty())tokens=cleaned;
        }
        if(tokens.isEmpty())throw new IllegalArgumentException("Не найдено слов длиннее одного символа");
        if(tokens.size()>MAX_TERMS)throw new IllegalArgumentException("Слишком много слов: максимум 7");
        ArrayList<String> blocks=new ArrayList<>(),variants=new ArrayList<>();
        boolean expanded=false;
        for(String token:tokens){
            LinkedHashSet<String> options=new LinkedHashSet<>();options.add(token);
            if(synonyms){
                List<String> group=GROUPS.get(token);
                // Recognise inflections of canonical nouns without stemming every word
                // (a broad stem such as "комп*" would match "компания").
                if(group==null){
                    if(token.startsWith("компьютер"))group=GROUPS.get("компьютер");
                    else if(token.startsWith("ноутбук"))group=GROUPS.get("ноутбук");
                    else if(token.startsWith("телефон"))group=GROUPS.get("телефон");
                    else if(token.startsWith("смартфон"))group=GROUPS.get("смартфон");
                    else if(token.startsWith("фотограф"))group=GROUPS.get("фотография");
                    else if(token.startsWith("велосипед"))group=GROUPS.get("велосипед");
                    else if(token.startsWith("автомобил"))group=GROUPS.get("автомобиль");
                }
                if(group!=null){for(String x:group){if(options.size()>=MAX_ALTERNATIVES)break;options.add(x);}}
            }
            ArrayList<String> alternatives=new ArrayList<>();
            for(String word:options){
                // sanitize to tokenize=unicode61 terms: FTS punctuation and operators are impossible.
                if(!word.matches("[\\p{L}\\p{N}]+"))throw new IllegalArgumentException("Недопустимый символ");
                // Keep colloquial alternatives exact: комп* would also match компания,
                // and ноут* would match unrelated words. Only typed original or
                // long canonical stems receive prefix matching.
                boolean prefix=options.size()==1?(word.length()>=4):
                    (word.equals("компьютер")||word.equals("ноутбук")||
                     word.equals("телефон")||word.equals("смартфон")||
                     word.equals("фотография")||word.equals("видеоролик")||
                     word.equals("автомобиль")||word.equals("велосипед")||
                     word.equals("путешествие"));
                alternatives.add("body:"+word+(prefix?"*":""));
                if(!variants.contains(word))variants.add(word);
            }
            if(options.size()>1)expanded=true;
            blocks.add(alternatives.size()==1?alternatives.get(0):"("+String.join(" OR ",alternatives)+")");
        }
        String description=expanded?"Локальные синонимы: "+String.join(", ",variants):"Поиск по словам";
        return new Plan(String.join(" AND ",blocks),normalize(input),description,tokens,variants,expanded);
    }
    private static String normalize(String s){return s.toLowerCase(Locale.ROOT).replace('ё','е').trim();}
    private static boolean containsWord(String text,String token){
        int i=0;while((i=text.indexOf(token,i))>=0){
            boolean left=i==0||!Character.isLetterOrDigit(text.charAt(i-1));
            int end=i+token.length();boolean right=end==text.length()||!Character.isLetterOrDigit(text.charAt(end));
            if(left&&right)return true;
            i=end;
        }return false;
    }
    private OfflineSynonymSearch(){}
}
