package org.openarchive.telegram;
import org.junit.Test;
import static org.junit.Assert.*;
public class OfflineSynonymSearchTest {
 @Test public void expandsComputerToPc(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("компьютер",true);
  assertTrue(p.fts.contains("body:пк"));assertTrue(p.fts.contains("body:компьютер*"));
  assertTrue(p.expanded);assertEquals("Вариант: пк",p.sourceMatch("Мой ПК работает"));
 }
 @Test public void directMatchIsMarked(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("ПК",true);
  assertEquals("Точное слово: пк",p.sourceMatch("Купил ПК!"));
 }
 @Test public void twoTermsUseAndAndGroupedOr(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("компьютер видео",true);
  assertTrue(p.fts.contains(" AND "));assertTrue(p.fts.contains(" OR "));
 }
 @Test public void removesQuestionWords(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("Найди где мы говорили про компьютер",true);
  assertEquals(1,p.terms.size());assertEquals("компьютер",p.terms.get(0));
 }
 @Test public void neverInjectsFtsSyntax(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("пк OR хак*",true);
  assertFalse(p.fts.contains(" OR хак*"));assertTrue(p.fts.contains("body:хак"));
 }
 @Test public void noSynonymsOptOut(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("пк",false);
  assertEquals("body:пк",p.fts);assertFalse(p.expanded);
 }
 @Test public void invalidAndGiantQueries(){
  try{OfflineSynonymSearch.make("…",true);fail();}catch(IllegalArgumentException ok){}
  try{OfflineSynonymSearch.make("x".repeat(141),true);fail();}catch(IllegalArgumentException ok){}
  try{OfflineSynonymSearch.make("одно два три четыре пять шесть семь восемь",true);fail();}catch(IllegalArgumentException ok){}
 }
 @Test public void inflectedWordAlsoFindsPc(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("о компьютере",true);
  assertTrue(p.fts.contains("body:пк"));
 }
 @Test public void preservesPrivacyAndLiteralEvidence(){
  OfflineSynonymSearch.Plan p=OfflineSynonymSearch.make("компьютер",true);
  assertEquals("Совпадение по началу слова",p.sourceMatch("тема компьютерные запчасти"));
  assertTrue(p.fts.length()<1000);
 }
}
